kilometers = float(input("Enter the number of kilometers: "))
Nautical = (kilometers / 10000) * 5400
print(str(kilometers), " kilometers is equal to ", str(Nautical), " Nautical Miles.")
