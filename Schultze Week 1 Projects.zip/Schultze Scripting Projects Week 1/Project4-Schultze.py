width = int(input("Enter with Width: "))
height = int(input("Enter with Height: "))
area = width * height
print("The area is", area, "square units.")
