base = int(input("Enter with Base: "))
height = int(input("Enter with Height: "))
area = .5 * base * height
print("The area is", area, "square units.")
