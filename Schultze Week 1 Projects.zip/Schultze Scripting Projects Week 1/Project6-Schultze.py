radius = float(input("Enter the Radius: "))
area = 3.14 * radius ** 2
print("The area of the circle is", area, "square units.")
