name = "Hayden Schultze"
address = "3117 S Gardenia Ct"
phone = "918 638 3702"
print(name)
print(address)
print(phone)
