m = float(input("Give the mass of an object: "))
v = float(input("Give the velocity of the object: "))
momentum = m * v
print("The momentum is " + str(momentum))
