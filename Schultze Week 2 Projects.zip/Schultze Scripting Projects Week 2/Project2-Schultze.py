length = input("Give the length of one side of a cube: ")
area = float(length) ** 2
SurfaceArea = float(area) * 6
print("The surface area is " + str(SurfaceArea))
