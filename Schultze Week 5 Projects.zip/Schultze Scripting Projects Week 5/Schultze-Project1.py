SideA = int(input("Enter the length of side 1: "))
SideB = int(input("Enter the length of side 2: "))
SideC = int(input("Enter the length of side 3: "))
if SideA == SideB and SideB == SideC:
    print("This is an equilateral triangle")
else:
    print("This is NOT an equlateral triangle")
